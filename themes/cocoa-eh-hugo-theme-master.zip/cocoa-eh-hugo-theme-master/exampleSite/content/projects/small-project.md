+++
title = "A small project example : add yours !"
description = "Blah blah blah"
date = "2017-01-01"
tags = ["projects"]
+++

Along with [Ford Prefect](https://en.wikipedia.org/wiki/Ford_Prefect_\(character\)), Dent barely escapes the Earth's destruction as it is demolished to make way for a *hyperspace bypass*. Arthur spends the next several years, still wearing his dressing gown, helplessly launched from crisis to crisis while trying to straighten out his lifestyle.  
 
> He rather enjoys tea, but seems to have trouble obtaining it in the far reaches of the galaxy.  
 
In time, he learns how to fly and carves a niche for himself as a sandwich-maker.